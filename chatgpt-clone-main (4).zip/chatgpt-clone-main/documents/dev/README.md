﻿This directory contains files used for developer work

- Dockerfile-app: used to build the DockerHub image
- eslintrc-stripped.js: alternate linting rules, used in development
- meilisearch.yml: Dockerfile for building meilisearch image independently from project