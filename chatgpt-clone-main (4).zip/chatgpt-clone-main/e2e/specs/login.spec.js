import { expect, test } from '@playwright/test';

test('landing page', async ({ page }) => {
  await page.goto('http://localhost:3080/');
  const pageTitle = await page.$eval('h1', pageTitle => pageTitle.textContent);
  console.log('pageTitle', pageTitle);
  expect(pageTitle.length).toBeGreaterThan(0);
  expect(pageTitle).toEqual('Welcome back');
});
